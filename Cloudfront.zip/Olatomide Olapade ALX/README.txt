Project: Deploy Static Website on AWS

The website's urls are shown below:

Cloudfront:https://d1fvg5ahbc8f04.cloudfront.net
S3 Bucket endpoint: http://my-226011901455-bucket.s3-website-us-east-1.amazonaws.com

Both urls work fine!